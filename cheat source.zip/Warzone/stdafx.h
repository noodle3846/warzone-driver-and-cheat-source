#pragma once

#include <stdio.h>
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <thread>
#include <iostream>
#include <mutex>
#include <random>
#include <dxgi1_4.h>
#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx12.h>
#include <MinHook.h>
#include <sstream >
#include <windows.h>
#include <intrin.h>
#include <stdio.h>
#include <intrin.h>
#include <string>
#include <map>
#include <vector>
#include <atomic>
#include <sstream>
#include <time.h>
#include <list>
#include <future>
#include <fstream>
#include <deque>

#include <d3d12.h>
#pragma comment(lib, "d3d12.lib")

#define Exit() 0





