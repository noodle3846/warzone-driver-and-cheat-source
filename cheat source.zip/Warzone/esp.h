#pragma once
#include "stdafx.h"
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

namespace main_game
{
	void main_loop(ImFont* font);
	void init(ImFont* font);
}
